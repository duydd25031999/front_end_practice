(function() {
  console.log('test.js');
})();
