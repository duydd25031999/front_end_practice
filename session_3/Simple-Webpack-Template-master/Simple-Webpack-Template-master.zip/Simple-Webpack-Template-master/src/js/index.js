(function() {
  console.log('yay 1');
})();
