# Project

This project was generated with:

- Webpack.

- SCSS 7-1 pattern.

# Command

`yarn`

`yarn start`

`yarn build:dev`

`yarn build:production`
